package com.springBasics.basicWebSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityApp.class, args);
	}

}
