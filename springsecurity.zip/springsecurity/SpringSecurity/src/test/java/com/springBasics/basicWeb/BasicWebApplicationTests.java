package com.springBasics.basicWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
